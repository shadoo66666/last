
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:task_app/constants/app_style.dart';

class SubtaskSection extends StatefulWidget {
  final List<TextEditingController> subtaskControllers;

  const SubtaskSection({
    super.key,
    required this.subtaskControllers,
  });

  @override
  _SubtaskSectionState createState() => _SubtaskSectionState();
}

class _SubtaskSectionState extends State<SubtaskSection> {
  List<bool?> isCheckedList = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.subtaskControllers.isNotEmpty)
          const Row(
            children: [
              FaIcon(FontAwesomeIcons.listCheck),
              Gap(5),
              Text(
                'Subtasks',
                style: AppStyle.headingOne,
              ),
            ],
          ),
        ..._buildSubtaskWidgets(),
        InkWell(
          onTap: _addSubtask,
          child: Row(
            children: const [
              FaIcon(FontAwesomeIcons.plus),
              Gap(11),
              Text(
                'Add Subtask',
                 style: AppStyle.headingOne,
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<Widget> _buildSubtaskWidgets() {
    List<Widget> widgets = [];
    for (int i = 0; i < widget.subtaskControllers.length; i++) {
      if (isCheckedList.length <= i) {
        isCheckedList.add(false);
      }
      widgets.add(
        Row(
          children: [
            Checkbox(
              value: isCheckedList[i],
              onChanged: (value) {
                setState(() {
                  isCheckedList[i] = value;
                });
              },
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: widget.subtaskControllers[i],
                decoration: const InputDecoration(
                  border: InputBorder.none,
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () {
                setState(() {
                  widget.subtaskControllers.removeAt(i);
                  isCheckedList.removeAt(i);
                });
              },
            ),
          ],
        ),
      );
    }
    return widgets;
  }

  void _addSubtask() {
    setState(() {
      widget.subtaskControllers.add(TextEditingController());
      isCheckedList.add(false);
    });
  }
}
